<?php namespace Mobkii\Commands;

abstract class Command {

	//

}
