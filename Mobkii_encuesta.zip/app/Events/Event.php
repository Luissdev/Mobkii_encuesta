<?php namespace Mobkii\Events;

abstract class Event {

	//

}
